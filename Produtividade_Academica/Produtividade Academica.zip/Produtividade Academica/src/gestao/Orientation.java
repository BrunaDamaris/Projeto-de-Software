package gestao;

public class Orientation {
	private String ProfessorName;
	private String Orientation;
	private String AssociateProject;
	
	public String getProfessorName() {
		return ProfessorName;
	}
	public void setProfessorName(String professorName) {
		this.ProfessorName = professorName;
	}
	public String getOrientation() {
		return Orientation;
	}
	public void setOrientation(String orientation) {
		this.Orientation = orientation;
	}
	
	public String getAssociateProject() {
		return AssociateProject;
	}
	public void setAssociateProject(String associateProject) {
		this.AssociateProject = associateProject;
	}
}
